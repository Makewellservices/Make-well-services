MAKE WELL SERVICES — SITE WEB
=============================

Fichiers:
- index.html : site complet et responsive
- logo.png   : logo fourni

Pour tester:
1. Ouvrir index.html dans un navigateur.
2. Pour publier, envoyer index.html et logo.png sur un hébergeur web.

À personnaliser avant publication:
- téléphone / WhatsApp
- e-mail
- adresse
- réseaux sociaux
- branchement réel du formulaire de contact
